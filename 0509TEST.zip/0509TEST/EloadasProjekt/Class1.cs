﻿using System;

namespace EloadasProject
{
    class Eloadas
    {
        private bool[,] foglalasok;

        public int SorokSzama { get; }
        public int HelyekSzama { get; }
        public int SzabadHelyek
        {
            get
            {
                int szabad = 0;
                for (int i = 0; i < SorokSzama; i++)
                {
                    for (int j = 0; j < HelyekSzama; j++)
                    {
                        if (!foglalasok[i, j])
                        {
                            szabad++;
                        }
                    }
                }
                return szabad;
            }
        }
        public bool Teli
        {
            get { return SzabadHelyek == 0; }
        }

        public Eloadas(int sorokSzama, int helyekSzama)
        {
            if (sorokSzama <= 0 || helyekSzama <= 0)
            {
                throw new ArgumentException("A sorok és helyek számának pozitívnak kell lennie.");
            }

            SorokSzama = sorokSzama;
            HelyekSzama = helyekSzama;
            foglalasok = new bool[sorokSzama, helyekSzama];
        }

        public bool Lefoglal()
        {
            for (int i = 0; i < SorokSzama; i++)
            {
                for (int j = 0; j < HelyekSzama; j++)
                {
                    if (!foglalasok[i, j])
                    {
                        foglalasok[i, j] = true;
                        return true;
                    }
                }
            }
            return false;
        }

        public bool Foglalt(int sorSzam, int helySzam)
        {
            if (sorSzam <= 0 || helySzam <= 0 || sorSzam > SorokSzama || helySzam > HelyekSzama)
            {
                throw new ArgumentException("Érvénytelen sor- vagy helyszám.");
            }

            return foglalasok[sorSzam - 1, helySzam - 1];
        }
    }
}
